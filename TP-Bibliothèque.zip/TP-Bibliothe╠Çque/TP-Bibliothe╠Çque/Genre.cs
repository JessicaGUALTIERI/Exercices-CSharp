﻿using System;
namespace TP_Bibliothèque
{
	public enum Genre
	{
		Adventure,
		Fiction,
		Horror,
		Historical
	}
}

